-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 28-05-2015 a las 22:51:45
-- Versión del servidor: 5.6.21
-- Versión de PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `happy_day`
--
CREATE DATABASE IF NOT EXISTS `happy_day` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `happy_day`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE IF NOT EXISTS `productos` (
`id` int(11) NOT NULL,
  `nombre` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `imagen` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `precio` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(400) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `etiqueta` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `imagen`, `precio`, `descripcion`, `etiqueta`) VALUES
(1, 'Dulcero de Dora', 'img/productos/infantil/arreglos/001_arreglo.jpg', '100', 'Arreglo infantil de Dora.', 'Infantiles, Arreglos'),
(2, 'Dulcero Toy Story', 'img/productos/infantil/arreglos/002_Arreglo.jpg', '100', 'Dulcero de toy story', 'Infantiles, Arreglos'),
(3, 'Arreglo de Miny', 'img/productos/infantil/arreglos/003_Arreglo.jpg', '100', 'Arreglo con forma de Miny', 'Infantiles, Arreglos'),
(4, 'Cascada Inflable', 'img/productos/infantil/inflables/001_inflable.jpg', '100', 'Inflable Infantil estilo cascada', 'Infantiles, Inflables'),
(5, 'Castillo Inflable', 'img/productos/infantil/inflables/002_Inflable.jpg', '100', 'Inflable infantil estilo castillo', 'Infantiles, Inflables'),
(6, 'Castillo Inflable Rosa', 'img/productos/infantil/inflables/003_Inflable.jpg', '100', 'Inflable infantil estilo castillo de color rosa', 'Infantiles, Inflables'),
(7, 'Invitaciones de animales', 'img/productos/infantil/invitaciones/001_invitacion.jpg', '100', 'Invitacion infantil de animalitos', 'Infantiles, Invitaciones'),
(8, 'Invitaciones de miky', 'img/productos/infantil/invitaciones/002_invitacion.jpg', '100', 'Invitacion infantil de miky', 'Infantiles, Invitaciones'),
(9, 'Invitacion de futbol', 'img/productos/infantil/invitaciones/003_invitacion.jpg', '100', 'Invitacion de balones de futbol', 'Infantiles, Invitaciones'),
(10, 'Antrada completa de globos rosa', 'img/productos/xvanos/globos/001_globos.jpg', '100', 'Entrada completamente cubierta de globos de color rosa.', 'XV anos, Globos'),
(11, 'Arreglo de boda', 'img/productos/Boda/arreglos/001.jpg', '100', 'Arreglo de Boda', 'Boda, Arreglo'),
(12, 'Arreglo de boda', 'img/productos/Boda/arreglos/002.jpg', '100', 'Arreglo de Boda', 'Boda, Arreglo'),
(13, 'Arreglo de boda', 'img/productos/Boda/arreglos/001.jpg', '100', 'Arreglo de Boda', 'Boda, Arreglo'),
(14, 'Arreglo de boda', 'img/productos/Boda/arreglos/002.jpg', '100', 'Arreglo de Boda', 'Boda, Arreglo'),
(15, 'Arreglo Formal', 'img/productos/Formal/arreglos/001.jpg', '100', 'Arreglos Formal', 'Formal, Arreglos'),
(16, 'Arreglo social', 'img/productos/Social/arreglos/001.jpg', '100', 'Arreglos Sicial', 'Social, Arreglo'),
(17, 'Baby Shower', 'img/productos/Baby Shower/arreglos/001.jpg', '100', 'Arreglo Baby Shower', 'Baby Shower, Arreglo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
`id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contrasena` varchar(50) NOT NULL,
  `tipo` varchar(20) NOT NULL DEFAULT 'usuario'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `correo`, `contrasena`, `tipo`) VALUES
(1, 'Graciela', 'Soto', 'graciela@example.com', 'secret', 'administrador'),
(2, 'Gadalupe', 'del Rosario', 'guadalupe@example.com', 'secret', 'administrador');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
